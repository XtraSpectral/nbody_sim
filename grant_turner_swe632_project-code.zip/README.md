# N-Body Simulation/Data Viz for Astral Spectra

Written for my SWE632 class, with focus on UI development. 

Credit to JavaTutorials101 for their 3D from scratch tutorial, which I used to inform the graphics rendering engine.

